$(document).ready(function() {
$("#submit").click(function(e) {
//Variables.
var Nom = $('#nom').val();
var email = $('#email').val();
//Expressions regulières
var test_email =/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
var test_nom = /^[A-Za-z]+( [A-Za-z]+)*$/g;
if (email.length == 0 && Nom.length == 0) {
$("#p1").text("Remplir nom");
$("#Nom").focus();
$("#p2").text("Remplir email");
$("#email").focus();
}
else if (Nom.length == 0 && email.length != 0 ) {
$("#p1").text("Remplir nom");
$("p2").text("");
$("#Nom").focus();
$("#email").focus();
}
else if (Nom.length != 0 && email.length == 0 ) {
$("#p2").text("Remplir email");
$("#p1").text("");
$("#Nom").focus();
$("#email").focus();
}
if (!Nom.match(test_nom) && Nom.length != 0) {
$("#p1").text("Un probleme dans le nom"); 
$("#Nom").focus();
}
else if (!email.match(test_email) && email.length != 0) {
$("#p2").text("Un probleme dans l'Adresse mail");
$("#email").focus();
}
if(Nom.length != 0 && email.length != 0){
if(email.match(test_email)&&Nom.match(test_nom)){
(alert)("Données validées par JQuery");
$("#p1").text("Nom valide");
$("#p2").text("email valide");
}
else if(!email.match(test_email)&&Nom.match(test_nom)) $("#p1").text("Nom valide"); 
else if(!email.match(test_email)&&Nom.match(test_nom)) $("#p2").text("email valide");    
}
});
});